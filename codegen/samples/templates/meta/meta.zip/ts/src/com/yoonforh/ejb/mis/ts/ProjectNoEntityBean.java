/*
 * $Id$
 *
 * Copyright (c) 2003 by %%company%%.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information
 * of %%company%%("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with %%company%%.
 */


package com.yoonforh.ejb.mis.%%function-id:lower%%;

import javax.ejb.*;
import java.util.*;
import java.sql.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.yoonforh.util.ApplicationException;
import com.yoonforh.util.JDBCUtil;
import com.yoonforh.ejb.meta.op.MetaOpEntityBean;

/**
 * %%table-name:csu_db%% entity bean class
 *
 * @version  $Revision$<br>
 *           created at %%timestamp%%
 * @author   %%company%%
 */

public class %%table-name:csu_db%%EntityBean implements MetaOpEntityBean {
    private EntityContext ctx;

    /**
     * The <code>Log</code> instance for this application.
     */
    private static Log log = LogFactory.getLog(%%table-name:csu_db%%EntityBean.class.getName());

    /** db table name */
    private final static String TABLE_NAME = "%%table-name%%";
    /** <db field names> - <java type> map */
    private final static HashMap FIELD_MAP = new HashMap();

    static {
	// fill in the set with names of table fields
%%field-name-put-block%%
    }

    private final static String[] KEY_FIELDS = {
%%key-field-names-block%%
    };

    /**
     * insert op
     */
    public %%table-name:csu_db%%EntityPK ejbCreate(HashMap dataMap)
		throws CreateException, ApplicationException {
	if (log.isTraceEnabled()) {
	    log.trace("ejbCreate(dataMap - " + dataMap + ")");
	}

	JDBCUtil.insert(TABLE_NAME, FIELD_MAP, KEY_FIELDS, dataMap);

	return new %%table-name:csu_db%%EntityPK(
%%pk-get-block%%
	    );
    }

    public void ejbPostCreate(HashMap dataMap) {
	if (log.isTraceEnabled()) {
	    log.trace("ejbPostCreate(dataMap - " + dataMap + ")");
	}

	// nothing to do now
    }

    public void ejbActivate() {
	if (log.isTraceEnabled()) {
	    log.trace("ejbActivate()");
	}
    }

    public void ejbPassivate() {
	if (log.isTraceEnabled()) {
	    log.trace("ejbPassivate()");
	}
    }

    public void ejbLoad() {
	if (log.isTraceEnabled()) {
	    log.trace("ejbLoad()");
	}

	/*
	 * in normal case, we should load data from JDBC connection here ...
	 * but in this case, we need not do anything ...
	 * 'cause entity beans in meta framework do not maintain states.
	 */
    }

    public void ejbStore() {
	if (log.isTraceEnabled()) {
	    log.trace("ejbStore()");
	}

	/*
	 * in normal case, we should store data into JDBC connection here ...
	 * but in this case, we need not do anything ...
	 * 'cause entity beans in meta framework do not maintain states.
	 */
    }

    public void ejbRemove() throws RemoveException {
	if (log.isTraceEnabled()) {
	    log.trace("ejbRemove()");
	}

	log.warn("ejbRemove() should not be called in Meta Framework,"
		 + " entity beans in meta framework do not maintain states.");
    }

    public void setEntityContext(EntityContext ctx) {
	this.ctx = ctx;

	if (log.isTraceEnabled()) {
	    log.trace("setEntityContext(ctx = " + ctx + ")");
	}
    }

    public void unsetEntityContext() {
	if (log.isTraceEnabled()) {
	    log.trace("unsetEntityContext()");
	}

	ctx = null;
    }

    /**
     * default ejb finder method impl.
     */
    public %%table-name:csu_db%%EntityPK ejbFindByPrimaryKey(%%table-name:csu_db%%EntityPK key) throws FinderException {
	if (log.isTraceEnabled()) {
	    log.trace("ejbFindByPrimaryKey(key - " + key + ")");
	}

	try {
	    Object[] keyValues = new Object[KEY_FIELDS.length];
%%pk-values-block%%

	    JDBCUtil.checkPrimaryKey(TABLE_NAME, FIELD_MAP, KEY_FIELDS, keyValues);
	} catch (ApplicationException e) {
	    log.error("query error", e);
	    throw new FinderException(e.getMessage());
	}

	// if no error then, ...
	return key;
    }
    
    /**
     * meta ejb finder method impl.
     */
    public %%table-name:csu_db%%EntityPK ejbFindByHashMap(HashMap dataMap) throws FinderException {
	if (log.isTraceEnabled()) {
	    log.trace("ejbFindByHashMap(map - " + dataMap + ")");
	}

	try {
	    String[] keyValues = new String[KEY_FIELDS.length];
%%pk-string-values-block%%

	    JDBCUtil.checkPrimaryKey(TABLE_NAME, FIELD_MAP, KEY_FIELDS, keyValues);

	} catch (ApplicationException e) {
	    log.error("query error", e);
	    throw new FinderException(e.getMessage());
	}

	// if no error then, ...
	return new %%table-name:csu_db%%EntityPK(dataMap);
    }
    
    /**
     * a meta operation impl.
     */
    public int update(HashMap dataMap) throws ApplicationException {
	if (log.isTraceEnabled()) {
	    log.trace("update(dataMap - " + dataMap + ")");
	}

	return JDBCUtil.update(TABLE_NAME, FIELD_MAP, KEY_FIELDS, dataMap);
    }

    /**
     * a meta operation impl.
     * mark as removed or purge (can be cascaded delete by semantics)
     */
    public void setRemoved(HashMap dataMap) throws ApplicationException {
	if (log.isTraceEnabled()) {
	    log.trace("setRemoved(dataMap - " + dataMap + ")");
	}

	/*
	 * by default, setRemoved deletes(purges) record from database table.
	 * following the semantics, change this with update method to 
	 * mark deleted field true, or add a cascading delete statements
	 * to keep the integrity of master - details relationship
	 */ 
	JDBCUtil.delete(TABLE_NAME, FIELD_MAP, KEY_FIELDS, dataMap);
    }


} // %%table-name:csu_db%%EntityBean
