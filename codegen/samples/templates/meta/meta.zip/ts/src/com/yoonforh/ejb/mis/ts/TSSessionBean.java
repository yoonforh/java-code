/*
 * $Id$
 *
 * Copyright (c) 2003 by %%company%%.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information
 * of %%company%%("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with %%company%%.
 */


package com.yoonforh.ejb.mis.%%function-id:lower%%;

import java.util.List;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.HashMap;
import java.sql.Date;
import java.sql.*;
import java.math.BigDecimal;
import javax.ejb.*;
import javax.rmi.PortableRemoteObject;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.yoonforh.util.ApplicationException;
import com.yoonforh.util.ServiceLocator;
import com.yoonforh.util.ServiceLocatorException;
import com.yoonforh.util.DateUtil;
import com.yoonforh.ejb.EJBConstants;
import com.yoonforh.ejb.meta.EJBMetaUtil;
import com.yoonforh.ejb.meta.op.MetaOpSessionBean;

/**
 * %%function-id:upper%% meta session bean class
 *
 * @version  $Revision$<br>
 *           created at %%timestamp%%
 * @author   %%company%%
 */

public class %%function-id:upper%%SessionBean implements MetaOpSessionBean {
    private SessionContext ctx;

    /**
     * The <code>Log</code> instance for this application.
     */
    private Log log = LogFactory.getLog(%%function-id:upper%%SessionBean.class.getName());

    public void ejbCreate() throws CreateException {
	if (log.isTraceEnabled()) {
	    log.trace("ejbCreate");
	}
    }

    public void ejbPostCreate() {
	if (log.isTraceEnabled()) {
	    log.trace("ejbPostCreate");
	}
    }
    
    public void ejbActivate() {
	if (log.isTraceEnabled()) {
	    log.trace("ejbActivate - which never be called for this stateless bean");
	}
    }

    public void ejbPassivate() {
	if (log.isTraceEnabled()) {
	    log.trace("ejbPassivate - which never be called for this stateless bean");
	}
    }

    public void ejbRemove() {
	if (log.isTraceEnabled()) {
	    log.trace("ejbRemove");
	}
    }

    public void setSessionContext(SessionContext ctx) {
	this.ctx = ctx;

	if (log.isTraceEnabled()) {
	    log.trace("setSessionContext(ctx = " + ctx + ")");
	}
    }

    /*
     * MetaOpSessionBean interface impl.
     */

    /**
     * @param dataList a list of HashMap which has <field name> - <value> map
     * @return update count
     */
    public int insertMeta(String tableName, List dataList) throws ApplicationException {
	if (log.isTraceEnabled()) {
	    log.trace("insertMeta(tableName = " + tableName + ", dataList = " + dataList + ")");
	}

	int updateCount = 0;

	Iterator it = dataList.iterator();
	while (it.hasNext()) {
	    HashMap dataMap = (HashMap) it.next();
	    EJBLocalObject entityBean = EJBMetaUtil.createLocalEntity(getClass().getClassLoader(),
								      tableName, dataMap);
	    updateCount++;
	}

	return updateCount;
    }

    /**
     * @param dataList a list of HashMap which has <field name> - <value> map
     * @return update count
     */
    public int updateMeta(String tableName, List dataList) throws ApplicationException {
	if (log.isTraceEnabled()) {
	    log.trace("updateMeta(tableName = " + tableName + ", dataList = " + dataList + ")");
	}

	int updateCount = 0;
	Iterator it = dataList.iterator();
	while (it.hasNext()) {
	    HashMap dataMap = (HashMap) it.next();
	    EJBLocalObject entityBean = EJBMetaUtil.getLocalEntity(getClass().getClassLoader(),
								   tableName, dataMap);
	    updateCount += EJBMetaUtil.invokeEntityMetaMethod(
		entityBean,
		EJBConstants.ENTITY_UPDATE_META_METHOD_NAME,
		dataMap);
	}

	return updateCount;
    }

    /**
     * @param dataList a list of HashMap which has <field name> - <value> map
     * @return update count
     */
    public int deleteMeta(String tableName, List dataList) throws ApplicationException {
	if (log.isTraceEnabled()) {
	    log.trace("deleteMeta(tableName = " + tableName + ", dataList = " + dataList + ")");
	}

	int updateCount = 0;
	Iterator it = dataList.iterator();
	while (it.hasNext()) {
	    HashMap dataMap = (HashMap) it.next();
	    EJBLocalObject entityBean = EJBMetaUtil.getLocalEntity(getClass().getClassLoader(),
								   tableName, dataMap);
	    EJBMetaUtil.invokeEntityMetaMethod(entityBean,
					       EJBConstants.ENTITY_DELETE_META_METHOD_NAME,
					       dataMap);
	    updateCount++;
	}

	return updateCount;
    }
    
}

