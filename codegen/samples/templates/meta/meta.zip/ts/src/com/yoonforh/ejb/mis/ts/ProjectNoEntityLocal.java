/*
 * $Id$
 *
 * Copyright (c) 2003 by %%company%%.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information
 * of %%company%%("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with %%company%%.
 */


package com.yoonforh.ejb.mis.%%function-id:lower%%;

import java.util.Collection;
import com.yoonforh.ejb.meta.op.MetaOpEntityLocalObject;

/**
 * %%table-name:csu_db%% entity bean local interface
 *
 * @version  $Revision$<br>
 *           created at %%timestamp%%
 * @author   %%company%%
 */

public interface %%table-name:csu_db%%EntityLocal extends MetaOpEntityLocalObject {
} // %%table-name:csu_db%%EntityLocal
