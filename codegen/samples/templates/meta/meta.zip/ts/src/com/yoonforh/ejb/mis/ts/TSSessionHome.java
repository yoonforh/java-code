/*
 * $Id$
 *
 * Copyright (c) 2003 by %%company%%.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information
 * of %%company%%("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with %%company%%.
 */


package com.yoonforh.ejb.mis.%%function-id:lower%%;

import java.rmi.RemoteException;

/**
 * %%function-id:upper%% meta session bean remote home interface
 *
 * @version  $Revision$<br>
 *           created at %%timestamp%%
 * @author   %%company%%
 */

public interface %%function-id:upper%%SessionHome extends javax.ejb.EJBHome {
    %%function-id:upper%%Session create() throws RemoteException, javax.ejb.CreateException;
}
