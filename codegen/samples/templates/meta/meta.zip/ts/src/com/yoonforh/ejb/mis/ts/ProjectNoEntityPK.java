/*
 * $Id$
 *
 * Copyright (c) 2003 by %%company%%.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information
 * of %%company%%("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with %%company%%.
 */


package com.yoonforh.ejb.mis.%%function-id:lower%%;

import java.util.HashMap;
import com.yoonforh.util.JDBCUtil;

/**
 * %%table-name:csu_db%% entity bean primary key class
 *
 * @version  $Revision$<br>
 *           created at %%timestamp%%
 * @author   %%company%%
 */

public class %%table-name:csu_db%%EntityPK implements java.io.Serializable {
%%pk-decl-block%%

    /**
     * usual case constructor
     */
    public %%table-name:csu_db%%EntityPK(
%%pk-args-block%%
	) {
%%pk-init-block%%
    }

    /**
     * constructor for meta framework
     */
    public %%table-name:csu_db%%EntityPK(HashMap dataMap) {
%%pk-hashmap-init-block%%
    }

    public %%table-name:csu_db%%EntityPK() { }

    public String toString() {
	return %%pk-to-string-block%%;
    }

    public int hashCode() {
	return toString().hashCode();
    }

    public boolean equals(Object obj) {
	return
%%pk-equals-block%%;
    }

}
