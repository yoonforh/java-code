/*
 * $Id$
 *
 * Copyright (c) 2004 by %%company%%.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information
 * of %%company%%("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with %%company%%.
 */


package %%package-name%%;

/**
 * Hello World program
 *
 * @version  $Revision$<br>
 *           created at %%timestamp%%
 * @author   Yoon Kyung Koo
 */

public class Hello {
    public static void main(String[] args) {
	System.out.println("%%message%%");
    }
}
